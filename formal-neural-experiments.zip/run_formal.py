"""Run the neural matrix in coding_plan §6.1 and two paired source-cue controls."""
import csv
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import pandas as pd
import yaml
from fakenews.config import load_config, save_config
from fakenews.features.masking import MASK_MODES, mask_dataframe

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
RUNS = Path("formal/runs")
MODELS = ("bilstm", "distilbert")
CONDITIONS = ("fusion", "concat")


def prepare_mask(mode):
    dest = Path("formal/data") / mode
    dest.mkdir(parents=True, exist_ok=True)
    stats = {}
    for split in ("train", "val", "test"):
        target = dest / (split + ".parquet")
        df = pd.read_parquet(Path("data/processed") / target.name)
        masked = mask_dataframe(df, mode)
        stats[split] = {"n": len(df), "changed": int((df.text_clean != masked.text_masked).sum())}
        df["text_clean"] = masked.text_masked
        tmp = target.with_suffix(".tmp")
        df.to_parquet(tmp, index=False)
        tmp.replace(target)
    (dest / "audit.json").write_text(json.dumps(stats, indent=2), encoding="utf8")


def run(model, condition, seed, mask="original"):
    key = f"{model}_{condition}_{seed}_{mask}"
    folder = RUNS / key
    folder.mkdir(parents=True, exist_ok=True)
    marker = folder / "completed.json"
    if marker.exists():
        return json.loads(marker.read_text())
    # A retry gets fresh outputs so partially written rows cannot enter an analysis.
    attempt = next(folder / f"attempt-{i}" for i in range(1,1000)
                   if not (folder / f"attempt-{i}").exists())
    attempt.mkdir()
    cfg = load_config("configs/base.yaml", f"configs/{model}.yaml").to_dict()
    cfg["distilbert"]["model_name"] = "assets/distilbert-base-uncased"
    cfg["paths"]["results_dir"] = str(attempt / "results")
    cfg["paths"]["models_dir"] = str(attempt / "models")
    if mask != "original":
        cfg["paths"]["processed_dir"] = str(Path("formal/data") / mask)
    cfg_file = save_config(cfg, attempt / "config.yaml")
    env = dict(os.environ, HF_HUB_OFFLINE="1", HF_HOME=str(ROOT/"scratch/hf"),
               PYTHONHASHSEED=str(seed), PYTHONIOENCODING="utf-8", OMP_NUM_THREADS="4",
               MPLCONFIGDIR=str(ROOT/"scratch/mpl"), TOKENIZERS_PARALLELISM="false")
    start = time.time()
    print(f"START {key} {time.strftime('%Y-%m-%d %H:%M:%S')}", flush=True)
    with (attempt / "train.log").open("w", encoding="utf8") as out:
        subprocess.run([sys.executable, "-u", "-m", f"fakenews.train.{model}",
                        "--config", str(cfg_file), "--condition", condition, "--seed", str(seed),
                        "--final"], env=env, check=True, stdout=out, stderr=subprocess.STDOUT)
    metrics = pd.read_csv(attempt / "results/metrics.csv")
    assert len(metrics) == 2 and set(metrics.split) == {"val", "test"}
    for row in metrics.itertuples():
        assert row.n == {"val":3851, "test":7701}[row.split]
        assert (attempt / f"results/predictions/{row.run_id}_{row.split}.parquet").is_file()
        assert (attempt / f"models/{model}/{row.run_id}/state_dict.pt").is_file()
    val = metrics[metrics.split == "val"].iloc[0]
    result = dict(model=model,condition=condition,seed=seed,mask=mask,attempt=str(attempt),
                  run_id=val.run_id,val_f1=float(val.f1),wall_seconds=time.time()-start)
    tmp = marker.with_suffix(".tmp")
    tmp.write_text(json.dumps(result, indent=2), encoding="utf8")
    tmp.replace(marker)
    print(f"DONE {key} {result['wall_seconds']:.0f}s", flush=True)
    return result


def main():
    main_runs = []
    for seed in (42,43,44):
        for model in MODELS:
            order = CONDITIONS if model == "bilstm" else ("concat","fusion")
            for condition in order:
                main_runs.append(run(model, condition, seed))
    selected = {}
    for model in MODELS:
        candidates = [r for r in main_runs if r["model"] == model and r["seed"] == 42]
        best = max(candidates, key=lambda r: (r["val_f1"], r["condition"] == "fusion"))
        selected[model] = best["condition"]
    Path("formal/selection.json").write_text(json.dumps(selected, indent=2), encoding="utf8")
    for mask in MASK_MODES:
        prepare_mask(mask)
        for model in MODELS:
            run(model, selected[model], 42, mask)
    print("Finished all 16 configurations", flush=True)


if __name__ == "__main__":
    main()
