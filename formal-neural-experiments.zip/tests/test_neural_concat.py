"""Regression checks for the single-encoder title/body baselines."""
import pandas as pd
import pytest

torch = pytest.importorskip("torch")

from fakenews.data.neural import BiLSTMDataset, DistilBertDataset, Vocab, collate_concat


def test_bilstm_concat_truncates_after_title_and_pads_only_at_batch_end():
    frame = pd.DataFrame({"id": [5, 8], "label": [1, 0], "title": ["a b c", "a"],
                          "text_clean": ["d e f", "f"]})
    vocab = Vocab.build(["a b c d e f"], min_freq=1)
    data = BiLSTMDataset(frame, vocab, max_title=2, max_body=4, concat=True)
    batch = collate_concat([data[0], data[1]])
    assert batch["ids"].tolist() == [[2, 3, 5, 6], [2, 7, 0, 0]]
    assert batch["lengths"].tolist() == [4, 2]
    assert batch["id"].tolist() == [5, 8]


def test_bert_concat_uses_three_delimiters_and_preserves_body_tail(tmp_path):
    transformers = pytest.importorskip("transformers")
    vocab = tmp_path / "vocab.txt"
    vocab.write_text("[PAD]\n[UNK]\n[CLS]\n[SEP]\n[MASK]\na\nb\nc\nd\ne\nf\n", encoding="utf-8")
    tokenizer = transformers.BertTokenizer(vocab_file=str(vocab))
    frame = pd.DataFrame({"id": [7], "label": [0], "title": ["a b c"],
                          "text_clean": ["a b c d e f"]})
    data = DistilBertDataset(frame, tokenizer, max_title=2, max_body=7, head=3,
                             tail=1, concat=True)
    tokens = tokenizer.convert_ids_to_tokens(data[0]["ids"].tolist())
    assert tokens == ["[CLS]", "a", "b", "[SEP]", "a", "b", "c", "f", "[SEP]"]
