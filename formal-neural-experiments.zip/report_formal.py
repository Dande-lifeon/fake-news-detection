"""Verify full-length checkpoints and produce the neural result tables."""
from pathlib import Path
import json
import re

import numpy as np
import pandas as pd
import torch
from transformers import AutoTokenizer

from fakenews.config import load_config
from fakenews.data.neural import Vocab
from fakenews.eval.bootstrap import bootstrap_f1, paired_bootstrap_delta
from fakenews.eval.metrics import compute_metrics, mcnemar
from fakenews.features.masking import mask_dataframe
from fakenews.models.bilstm import ConcatBiLSTM, DualBiLSTM
from fakenews.models.distilbert import ConcatDistilBert, DualDistilBert
from fakenews.train import bilstm, distilbert
from fakenews.train.neural_common import evaluate


def load_weights(run, cfg, folder, frame):
    concat = run["condition"] == "concat"
    if run["model"] == "bilstm":
        vocab = Vocab.load(folder / "vocab.tsv")
        model = (ConcatBiLSTM(len(vocab.stoi), cfg.bilstm) if concat else
                 DualBiLSTM(len(vocab.stoi), cfg.bilstm))
        loader = bilstm._loader(frame, vocab, cfg, shuffle=False, concat=concat)
    else:
        tokenizer = AutoTokenizer.from_pretrained(folder / "tokenizer")
        model = (ConcatDistilBert(cfg.distilbert.model_name) if concat else
                 DualDistilBert(cfg.distilbert.model_name))
        loader = distilbert._loader(frame, tokenizer, cfg, shuffle=False, concat=concat)
    model.load_state_dict(torch.load(folder / "state_dict.pt", map_location="cpu",
                                     weights_only=True), strict=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return evaluate(model.to(device), loader, device)["probs"]


def main():
    runs = [json.loads(p.read_text()) for p in sorted(Path("formal/runs").glob("*/completed.json"))]
    best = json.loads(Path("formal/selection.json").read_text())
    expected = {(m,c,s,"original") for m in best for c in ("fusion","concat") for s in (42,43,44)}
    expected.update((m,c,42,k) for m,c in best.items() for k in ("dateline_url","format"))
    assert len(runs) == 16 and set((r["model"], r["condition"], r["seed"], r["mask"]) for r in runs) == expected
    dest = Path("formal/summary")
    dest.mkdir(exist_ok=True)
    records, predictions, verifications = [], {}, []
    base = Path("data/processed")
    truth = {s: pd.read_parquet(base / f"{s}.parquet", columns=["id","label"]) for s in ("val","test")}
    for model, selected in best.items():
        candidates = [r for r in runs if r["model"]==model and r["seed"]==42 and r["mask"]=="original"]
        assert selected == max(candidates,key=lambda r:(r["val_f1"],r["condition"]=="fusion"))["condition"]
    mask_audits = {}
    for mode in ("dateline_url", "format"):
        audit = {}
        for split in ("train","val","test"):
            cols = ["id","label","title","text_clean"]
            orig = pd.read_parquet(base / f"{split}.parquet",columns=cols)
            masked = pd.read_parquet(Path("formal/data") / mode / f"{split}.parquet",columns=cols)
            pd.testing.assert_frame_equal(orig[cols[:3]],masked[cols[:3]])
            expected_text = mask_dataframe(orig,mode).text_masked
            np.testing.assert_array_equal(masked.text_clean.to_numpy(),expected_text.to_numpy())
            audit[split] = {"n":len(orig),"changed":int((orig.text_clean!=masked.text_clean).sum())}
        assert audit == json.loads((Path("formal/data")/mode/"audit.json").read_text())
        mask_audits[mode] = audit
    for run in runs:
        attempt = Path(run["attempt"])
        cfg = load_config(attempt / "config.yaml")
        reference = load_config("configs/base.yaml", "configs/"+run["model"]+".yaml").to_dict()
        reference["distilbert"]["model_name"] = cfg.distilbert.model_name
        assert cfg.bilstm.to_dict() == reference["bilstm"] and cfg.distilbert.to_dict() == reference["distilbert"]
        epochs = re.findall(r'epoch (\d+): loss=',(attempt/"train.log").read_text(encoding="utf8"))
        assert (len(epochs)==3 if run["model"]=="distilbert" else 3 <= len(epochs) <= 10)
        model_dir = Path(cfg.paths.models_dir) / run["model"] / run["run_id"]
        metrics = pd.read_csv(attempt/"results/metrics.csv")
        assert len(metrics) == 2 and set(metrics.split) == {"val","test"}
        for row in metrics.itertuples():
            pred = pd.read_parquet(attempt / f"results/predictions/{row.run_id}_{row.split}.parquet")
            assert pred.id.is_unique and pred.y_prob.between(0,1).all()
            np.testing.assert_array_equal(pred.id,truth[row.split].id)
            np.testing.assert_array_equal(pred.y_true,truth[row.split].label)
            assert (row.model,row.condition,row.seed,row.run_id,row.threshold) == (
                run["model"],run["condition"],run["seed"],run["run_id"],0.5)
            values = compute_metrics(pred.y_true,pred.y_prob)
            for k,v in values.items():
                np.testing.assert_allclose(getattr(row,k),v,atol=1e-9)
            lo, hi = bootstrap_f1(pred.y_true,pred.y_prob)
            records.append(dict(model=row.model,condition=row.condition,seed=row.seed,mask=run["mask"],
                                split=row.split,epochs_run=len(epochs),f1_ci_low=lo,f1_ci_high=hi,
                                gate_mean=row.gate_mean,wall_seconds=run["wall_seconds"],**values))
            if row.split == "test":
                predictions[(row.model,row.condition,row.seed,run["mask"])] = pred
            else:
                frame = pd.read_parquet(Path(cfg.paths.processed_dir)/"val.parquet").head(16)
                probs = load_weights(run, cfg, model_dir, frame)
                delta = np.abs(probs - pred.y_prob.head(16).to_numpy())
                np.testing.assert_allclose(delta,0,atol=1e-4)
                verifications.append({"run_id":row.run_id,"mask":run["mask"],
                                      "reload_rows":16,"max_abs_difference":float(delta.max())})
    data = pd.DataFrame(records)
    data.to_csv(dest/"all-runs.csv",index=False,encoding="utf-8-sig")
    tests = data[(data.split=="test") & (data["mask"]=="original")]
    summary = tests.groupby(["model","condition"]).agg(seeds=("seed","nunique"),
              f1_mean=("f1","mean"),f1_sd=("f1","std"),accuracy_mean=("accuracy","mean"),
              accuracy_sd=("accuracy","std"),pr_auc_mean=("pr_auc","mean"),pr_auc_sd=("pr_auc","std"))
    assert (summary.seeds==3).all()
    summary.to_csv(dest/"three-seed-summary.csv",encoding="utf-8-sig")
    pairs = []
    def compare(model, seed, descr, a, b):
        np.testing.assert_array_equal(a.id,b.id)
        y = a.y_true.to_numpy()
        pa, pb = a.y_prob.to_numpy(), b.y_prob.to_numpy()
        pairs.append(dict(model=model,seed=seed,comparison=descr,
                          f1_a=compute_metrics(y,pa)["f1"],f1_b=compute_metrics(y,pb)["f1"],
                          **paired_bootstrap_delta(y,pa,pb),**mcnemar(y,pa>=0.5,pb>=0.5)))
    for model, condition in best.items():
        for seed in (42,43,44):
            compare(model,seed,"fusion minus concat",predictions[model,"fusion",seed,"original"],
                    predictions[model,"concat",seed,"original"])
        for mask in ("dateline_url","format"):
            compare(model,42,f"{condition}: {mask} minus original",predictions[model,condition,42,mask],
                    predictions[model,condition,42,"original"])
    pd.DataFrame(pairs).to_csv(dest/"paired-comparisons.csv",index=False,encoding="utf-8-sig")
    (dest/"verification.json").write_text(json.dumps({"prediction_rows":int(data.n.sum()),"mask_audits":mask_audits,
          "checkpoints":verifications},indent=2),encoding="utf8")
    print(summary)

if __name__ == "__main__":
    main()
